package com.example.dummycellphonesfactory.ui.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.preference.PreferenceManager;

import com.example.dummycellphonesfactory.R;
import com.example.dummycellphonesfactory.databinding.FragmentViewBeltBinding;

public class ViewBeltFragment extends Fragment {

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        com.example.dummycellphonesfactory.databinding.FragmentViewBeltBinding binding = FragmentViewBeltBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(PreferenceManager.getDefaultSharedPreferences(requireActivity()).getString("view_belt_endpoint","about:blank")));
        startActivity(browserIntent);
        return root;
    }

}

package com.example.dummycellphonesfactory.ui.home;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.preference.PreferenceManager;

import com.example.dummycellphonesfactory.R;
import com.example.dummycellphonesfactory.databinding.FragmentAddOrderBinding;

import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class AddOrderFragment extends Fragment {

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        com.example.dummycellphonesfactory.databinding.FragmentAddOrderBinding binding = FragmentAddOrderBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        binding.addOrderButton.setOnClickListener(v -> {
            binding.addOrderResult.setText(R.string.requesting);
            class Task extends AsyncTask<Void , Void , Void> {
                @Override
                protected Void doInBackground(Void... voids) {
                    String result;
                    try {
                        TrustManager[] trustAllCerts = new TrustManager[]{
                                new X509TrustManager() {
                                    public X509Certificate[] getAcceptedIssuers() {
                                        return new X509Certificate[0];
                                    }

                                    public void checkClientTrusted(
                                            X509Certificate[] certs, String authType) {
                                    }

                                    public void checkServerTrusted(
                                            X509Certificate[] certs, String authType) {
                                    }
                                }
                        };

                        SSLContext sc = SSLContext.getInstance("SSL");
                        sc.init(null, trustAllCerts, new SecureRandom());
                        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

                        HostnameVerifier validHosts = (arg0, arg1) -> true;
                        HttpsURLConnection.setDefaultHostnameVerifier(validHosts);

                        URL url = new URL(PreferenceManager.getDefaultSharedPreferences(requireActivity()).getString("add_order_endpoint", "about:blank"));
                        HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
                        conn.setRequestMethod("POST");
                        String auth = PreferenceManager.getDefaultSharedPreferences(requireActivity()).getString("username", "") + ":" + PreferenceManager.getDefaultSharedPreferences(requireActivity()).getString("password", "about:blank");
                        byte[] encodedAuth = Base64.encode(auth.getBytes(StandardCharsets.UTF_8), 0);
                        String authHeaderValue = "Basic " + new String(encodedAuth);
                        conn.setRequestProperty("Authorization", authHeaderValue);
                        conn.setRequestProperty("Content-Type", "application/json");
                        conn.setDoOutput(true);
                        String jsonInputString = "{ \"client\": \"" + binding.addOrderEditTextClient.getText().toString() + "\", \"itemtype\": \"" + binding.addOrderEditTextItemType.getText().toString() + "\", \"quantity\": \"" + binding.addOrderQuantity.getText().toString() + "\" }";
                        try (OutputStream os = conn.getOutputStream()) {
                            byte[] input = jsonInputString.getBytes(StandardCharsets.UTF_8);
                            os.write(input, 0, input.length);
                        }
                        conn.connect();
                        if (conn.getResponseCode() == 200) {
                            result = "OK";
                        } else {
                            result = "ERROR";
                        }
                    } catch (Exception e) {
                        result = "ERROR";
                    }

                    String finalResult = result;
                    requireActivity().runOnUiThread(() -> binding.addOrderResult.setText(finalResult));

                    return null;
                }

            }
            new Task().execute();

        });
        return root;
    }

}

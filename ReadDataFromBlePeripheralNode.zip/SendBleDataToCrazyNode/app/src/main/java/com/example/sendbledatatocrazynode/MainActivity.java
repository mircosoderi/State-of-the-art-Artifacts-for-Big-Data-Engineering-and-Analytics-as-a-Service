package com.example.sendbledatatocrazynode;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import com.google.android.material.snackbar.Snackbar;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Handler;
import android.provider.Settings;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import com.example.sendbledatatocrazynode.databinding.ActivityMainBinding;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

@RequiresApi(api = Build.VERSION_CODES.M)
public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    BluetoothManager bluetoothManager;
    BluetoothAdapter bluetoothAdapter;
    BluetoothLeScanner bluetoothLeScanner;
    BluetoothGatt bluetoothGatt;
    boolean scanning;
    Handler handler = new Handler();
    static final long SCAN_PERIOD = 5000;
    public static final int PROPERTY_NOTIFY = 16;
    private String deviceName = "";
    private String deviceAddress ="";
    private String centralColor = "white";
    private boolean reading = false;
    private boolean scanned = false;

    private boolean checkForCharacteristicProperty(BluetoothGattCharacteristic chara, int attr) {
        return chara != null && ((chara.getProperties() & attr) != 0);
    }

    void scanLeDevice() {
        if (!scanning) {
            // Stops scanning after a predefined scan period.
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        scanning = false;
                        bluetoothLeScanner.stopScan(leScanCallback);
                    }
                    catch(SecurityException se) {
                        append("ERROR! Authorization denied by user.");
                    }
                }
            }, SCAN_PERIOD);
            try {
                bluetoothLeScanner.startScan(leScanCallback);
                scanning = true;
            }
            catch(SecurityException se) {
                append("ERROR! Authorization denied by user.");
            }
        } else {
            try {
                bluetoothLeScanner.stopScan(leScanCallback);
                scanning = false;
            }
            catch(SecurityException se) {
                append("ERROR! Authorization denied by user.");
            }
        }
    };

    private final BluetoothGattCallback gattCallback=new BluetoothGattCallback() {

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (newState== BluetoothProfile.STATE_CONNECTED && !reading){
                try {
                    gatt.discoverServices();
                }
                catch(SecurityException se) {
                    append("ERROR! Authorization denied by user.");
                }
            }
        }

        private SSLSocketFactory getSingleSocketFactory(InputStream caCrtFileInputStream) throws Exception {
            Security.addProvider(new BouncyCastleProvider());
            X509Certificate caCert = null;
            BufferedInputStream bis = new BufferedInputStream(caCrtFileInputStream);
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            while (bis.available() > 0) {
                caCert = (X509Certificate) cf.generateCertificate(bis);
            }
            KeyStore caKs = KeyStore.getInstance(KeyStore.getDefaultType());
            caKs.load(null, null);
            caKs.setCertificateEntry("cert-certificate", caCert);
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init(caKs);
            SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
            sslContext.init(null, tmf.getTrustManagers(), null);
            return sslContext.getSocketFactory();
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status==BluetoothGatt.GATT_SUCCESS && !reading){
                List<BluetoothGattService> services = gatt.getServices();
                if(services.isEmpty()) {
                    try {
                        append("ERROR! No services.");
                    }
                    catch(Exception e) {}
                }
                else for (BluetoothGattService gattService : services) {
                    for (BluetoothGattCharacteristic gattCharacteristic : gattService.getCharacteristics()) {
                        try {
                            if(checkForCharacteristicProperty(gattCharacteristic, PROPERTY_NOTIFY)) {
                                try {
                                    gatt.setCharacteristicNotification(gattCharacteristic, true);
                                    UUID uuid = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
                                    BluetoothGattDescriptor descriptor = gattCharacteristic.getDescriptor(uuid);
                                    descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                                    gatt.writeDescriptor(descriptor);
                                    gatt.readCharacteristic(gattCharacteristic);
                                    reading = true;

                                    // subscribe to central MQTT broker
                                    try {
                                        String clientId = Settings.Secure.getString(getApplicationContext().getContentResolver(),Settings.Secure.ANDROID_ID);
                                        MqttAndroidClient mqttClient = new MqttAndroidClient(getApplicationContext(),"ssl://192.168.8.101:8883", clientId);
                                        MqttConnectOptions options = new MqttConnectOptions();
                                        options.setUserName("admin");
                                        options.setPassword("admin".toCharArray());
                                        try {
                                            InputStream caCrtFileI = getResources().openRawResource(R.raw.ca);
                                            options.setSocketFactory(getSingleSocketFactory(caCrtFileI));
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                        mqttClient.setCallback(new MqttCallback() {
                                            public void connectionLost(Throwable cause) {}
                                            public void messageArrived(String topic, MqttMessage message) {
                                                centralColor = new String(message.getPayload());
                                                runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        View myFragment = findViewById(R.id.diamogliunid);
                                                        if(centralColor.split("\\\"")[7].equals("0")) myFragment.setBackgroundColor(Color.parseColor("green"));
                                                        else if(centralColor.split("\\\"")[7].equals("1")) myFragment.setBackgroundColor(Color.parseColor("yellow"));
                                                        else myFragment.setBackgroundColor(Color.parseColor("red"));
                                                    }
                                                });
                                            }
                                            public void deliveryComplete(IMqttDeliveryToken token) {}
                                        });
                                        IMqttToken token = mqttClient.connect(options);
                                        token.setActionCallback(new IMqttActionListener() {

                                            @Override
                                            public void onSuccess(IMqttToken arg0) {
                                                try {
                                                    mqttClient.subscribe("smartxxxx/predictionoutput", 2);
                                                } catch (MqttException e) {
                                                    e.printStackTrace();
                                                }
                                            }

                                            @Override
                                            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {

                                            }

                                        });

                                    }
                                    catch(Exception e) {}

                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toolbar mActionBarToolbar = (Toolbar) findViewById(R.id.toolbar);
                                            setSupportActionBar(mActionBarToolbar);
                                            getSupportActionBar().setTitle(deviceName);
                                        }
                                    });

                                }
                                catch(SecurityException pce) {
                                    append("ERROR! Authorization denied by user.");
                                }
                            }
                        }
                        catch(Exception ecc) {
                            append("ERROR! "+ecc.getLocalizedMessage());
                        }
                    }
                }
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            //we are still connected to the service
            if (status==BluetoothGatt.GATT_SUCCESS){
                //send the characteristic to broadcastupdate
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            append(new String(characteristic.getValue(), StandardCharsets.UTF_8).split("\\\\\"")[1]);
            //send the characteristic to broadcastupdate
        }
    };

    // Device scan callback.
    ScanCallback leScanCallback =
            new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, ScanResult result) {
                    super.onScanResult(callbackType, result);
                    if(reading) return;
                    BluetoothDevice device = result.getDevice();
                    try {
                        if(Objects.equals(device.getAddress(), deviceAddress)) {
                            scanLeDevice();
                            deviceName = device.getName();
                            bluetoothGatt = device.connectGatt(getApplicationContext(), false, gattCallback);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toolbar mActionBarToolbar = (Toolbar) findViewById(R.id.toolbar);
                                    setSupportActionBar(mActionBarToolbar);
                                    getSupportActionBar().setTitle("Connecting...");
                                }
                            });
                        }
                    }
                    catch(SecurityException se) {
                        append("ERROR! Authorization denied by user.");
                    }
                }

                @Override
                public void onScanFailed(int errorCode) {
                    super.onScanFailed(errorCode);
                    append("ERROR! Scan failed with error " + errorCode);
                }

                @Override
                public void onBatchScanResults(List<ScanResult> results) {
                    super.onBatchScanResults(results);
                }
            };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1001);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        bluetoothManager = getSystemService(BluetoothManager.class);
        bluetoothAdapter = bluetoothManager.getAdapter();
        bluetoothLeScanner = bluetoothAdapter.getBluetoothLeScanner();

        if (bluetoothAdapter == null) {
            append("ERROR! Bluetooth is not supported.");
        } else {
            if (!bluetoothAdapter.isEnabled()) {
                append("ERROR! Bluetooth is supported but not enabled.");
            } else {
                try {
                    scanned = true;
                    Intent intent = new Intent("com.google.zxing.client.android.SCAN");
                    intent.putExtra("SCAN_MODE", "QR_CODE_MODE"); // "PRODUCT_MODE for bar codes
                    startActivityForResult(intent, 0);
                } catch (Exception e) {
                    Uri marketUri = Uri.parse("market://details?id=com.google.zxing.client.android");
                    Intent marketIntent = new Intent(Intent.ACTION_VIEW, marketUri);
                    startActivity(marketIntent);
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0) {
            if (resultCode == RESULT_OK) {
                deviceAddress = data.getStringExtra("SCAN_RESULT");
                BluetoothDevice device = bluetoothAdapter.getRemoteDevice(deviceAddress);
                try {
                    deviceName = device.getName();
                    bluetoothGatt = device.connectGatt(getApplicationContext(), false, gattCallback);
                } catch (SecurityException se) {
                }
            }
            if(resultCode == RESULT_CANCELED){
                //handle cancel
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            bluetoothGatt.disconnect();
            bluetoothGatt.close();
        }
        catch(SecurityException se) {
            append("ERROR! Missing user authorization.");
        }
    }

    void append(String what) {
        try {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    TextView lvItem = ((TextView) findViewById(R.id.textview_first));
                    lvItem.setTextColor(Color.parseColor("black"));
                    try { if(what.split(" ").length == 2) lvItem.setBackgroundColor(Color.parseColor(what.split(" ")[1])); } catch(Exception e) {}
                    lvItem.setTextSize(60);
                    lvItem.setText(what.split(" ")[0]);
                }
            });

            // also send to central server
            try {
                // NO SECURITY - DEMO PURPOSES
                // Create a trust manager that does not validate certificate chains
                TrustManager[] trustAllCerts = new TrustManager[]{
                        new X509TrustManager() {
                            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                                return null;
                            }
                            public void checkClientTrusted(
                                    java.security.cert.X509Certificate[] certs, String authType) {
                            }
                            public void checkServerTrusted(
                                    java.security.cert.X509Certificate[] certs, String authType) {
                            }
                        }
                };

                // Install the all-trusting trust manager
                try {
                    SSLContext sc = SSLContext.getInstance("SSL");
                    sc.init(null, trustAllCerts, new java.security.SecureRandom());
                    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
                } catch (Exception e) {
                }

                // Trust any client
                // Create all-trusting host name verifier
                HostnameVerifier validHosts = new HostnameVerifier() {
                    @Override
                    public boolean verify(String arg0, SSLSession arg1) {
                        return true;
                    }
                };
                // All hosts will be valid
                HttpsURLConnection.setDefaultHostnameVerifier(validHosts);

                URL url = new URL("https://192.168.8.101:2120/inject");
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "text/plain");
                con.setRequestProperty("Accept", "*/*");
                con.setRequestProperty("Authorization", "Basic YWRtaW46YWRtaW4=");
                con.setDoOutput(true);
                try (OutputStream os = con.getOutputStream()) {
                    byte[] input = what.split(" ")[0].getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(con.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    //System.out.println(response.toString());
                }
            }
            catch(Exception e) {
                String ops = "ops";
            }

        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

}
package com.example.sendbledatatocrazynode;

import android.app.Application;

public class MyApplication extends Application {
    private boolean isServerInit;
    private boolean isServerInitComplete;

    public String getCentralAssessmentPort() {
        return centralAssessmentPort;
    }

    public void setCentralAssessmentPort(String centralAssessmentPort) {
        this.centralAssessmentPort = centralAssessmentPort;
    }

    public String centralAssessmentPort;
    public boolean isServerInit() {
        return isServerInit;
    }
    public void isServerInit(boolean isServerInit) {
        this.isServerInit = isServerInit;
    }
    public boolean isServerInitComplete() {
        return isServerInitComplete;
    }
    public void isServerInitComplete(boolean isServerInitComplete) {
        this.isServerInitComplete = isServerInitComplete;
    }
}

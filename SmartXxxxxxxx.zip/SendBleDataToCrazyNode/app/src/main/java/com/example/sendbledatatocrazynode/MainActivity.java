package com.example.sendbledatatocrazynode;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import com.google.android.material.snackbar.Snackbar;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.Settings;
import android.view.View;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import com.example.sendbledatatocrazynode.databinding.ActivityMainBinding;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.Security;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

@RequiresApi(api = Build.VERSION_CODES.M)
public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    BluetoothManager bluetoothManager;
    BluetoothAdapter bluetoothAdapter;
    BluetoothLeScanner bluetoothLeScanner;
    BluetoothGatt bluetoothGatt;
    boolean scanning;
    Handler handler = new Handler();
    static final long SCAN_PERIOD = 5000;
    public static final int PROPERTY_NOTIFY = 16;
    private String deviceName = "";
    private String deviceAddress ="";
    private String centralColor = "white";
    private boolean reading = false;
    private boolean scanned = false;

    private boolean checkForCharacteristicProperty(BluetoothGattCharacteristic chara, int attr) {
        return chara != null && ((chara.getProperties() & attr) != 0);
    }

    void scanLeDevice() {
        if (!scanning) {
            // Stops scanning after a predefined scan period.
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        scanning = false;
                        bluetoothLeScanner.stopScan(leScanCallback);
                    }
                    catch(SecurityException se) {
                        append("ERROR! Authorization denied by user.");
                    }
                }
            }, SCAN_PERIOD);
            try {
                bluetoothLeScanner.startScan(leScanCallback);
                scanning = true;
            }
            catch(SecurityException se) {
                append("ERROR! Authorization denied by user.");
            }
        } else {
            try {
                bluetoothLeScanner.stopScan(leScanCallback);
                scanning = false;
            }
            catch(SecurityException se) {
                append("ERROR! Authorization denied by user.");
            }
        }
    };

    private final BluetoothGattCallback gattCallback=new BluetoothGattCallback() {

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (newState== BluetoothProfile.STATE_CONNECTED && !reading){
                try {
                    gatt.discoverServices();
                }
                catch(SecurityException se) {
                    append("ERROR! Authorization denied by user.");
                }
            }
        }

        private SSLSocketFactory getSingleSocketFactory(InputStream caCrtFileInputStream) throws Exception {
            Security.addProvider(new BouncyCastleProvider());
            X509Certificate caCert = null;
            BufferedInputStream bis = new BufferedInputStream(caCrtFileInputStream);
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            while (bis.available() > 0) {
                caCert = (X509Certificate) cf.generateCertificate(bis);
            }
            KeyStore caKs = KeyStore.getInstance(KeyStore.getDefaultType());
            caKs.load(null, null);
            caKs.setCertificateEntry("cert-certificate", caCert);
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init(caKs);
            SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
            sslContext.init(null, tmf.getTrustManagers(), null);
            return sslContext.getSocketFactory();
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status==BluetoothGatt.GATT_SUCCESS && !reading){
                List<BluetoothGattService> services = gatt.getServices();
                if(services.isEmpty()) {
                    try {
                        append("ERROR! No services.");
                    }
                    catch(Exception e) {}
                }
                else for (BluetoothGattService gattService : services) {
                    for (BluetoothGattCharacteristic gattCharacteristic : gattService.getCharacteristics()) {
                        try {
                            if(checkForCharacteristicProperty(gattCharacteristic, PROPERTY_NOTIFY)) {
                                try {
                                    gatt.setCharacteristicNotification(gattCharacteristic, true);
                                    UUID uuid = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
                                    BluetoothGattDescriptor descriptor = gattCharacteristic.getDescriptor(uuid);
                                    descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                                    gatt.writeDescriptor(descriptor);
                                    gatt.readCharacteristic(gattCharacteristic);
                                    reading = true;

                                    // subscribe to central MQTT broker
                                    try {
                                        String clientId = Settings.Secure.getString(getApplicationContext().getContentResolver(),Settings.Secure.ANDROID_ID);
                                        MqttAndroidClient mqttClient = new MqttAndroidClient(getApplicationContext(),"ssl://192.168.8.101:8883", clientId);
                                        MqttConnectOptions options = new MqttConnectOptions();
                                        options.setUserName("admin");
                                        options.setPassword("admin".toCharArray());
                                        try {
                                            InputStream caCrtFileI = getResources().openRawResource(R.raw.ca);
                                            options.setSocketFactory(getSingleSocketFactory(caCrtFileI));
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                        mqttClient.setCallback(new MqttCallback() {
                                            public void connectionLost(Throwable cause) {}
                                            public void messageArrived(String topic, MqttMessage message) {
                                                centralColor = new String(message.getPayload());
                                                runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        View myFragment = findViewById(R.id.diamogliunid);
                                                        if(centralColor.split("\\\"")[7].equals("0")) myFragment.setBackgroundColor(Color.parseColor("green"));
                                                        else if(centralColor.split("\\\"")[7].equals("1")) myFragment.setBackgroundColor(Color.parseColor("yellow"));
                                                        else myFragment.setBackgroundColor(Color.parseColor("red"));
                                                    }
                                                });
                                            }
                                            public void deliveryComplete(IMqttDeliveryToken token) {}
                                        });
                                        IMqttToken token = mqttClient.connect(options);
                                        token.setActionCallback(new IMqttActionListener() {

                                            @Override
                                            public void onSuccess(IMqttToken arg0) {
                                                try {
                                                    mqttClient.subscribe("smartxxxxxxxx/"+deviceAddress.replaceAll(":","")+"/predictionoutput", 2);
                                                } catch (MqttException e) {
                                                    e.printStackTrace();
                                                }
                                            }

                                            @Override
                                            public void onFailure(IMqttToken asyncActionToken, Throwable exception) {

                                            }

                                        });

                                    }
                                    catch(Exception e) {}

                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toolbar mActionBarToolbar = (Toolbar) findViewById(R.id.toolbar);
                                            setSupportActionBar(mActionBarToolbar);
                                            getSupportActionBar().setTitle(deviceName);
                                        }
                                    });

                                }
                                catch(SecurityException pce) {
                                    append("ERROR! Authorization denied by user.");
                                }
                            }
                        }
                        catch(Exception ecc) {
                            append("ERROR! "+ecc.getLocalizedMessage());
                        }
                    }
                }
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            //we are still connected to the service
            if (status==BluetoothGatt.GATT_SUCCESS){
                //send the characteristic to broadcastupdate
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            append(new String(characteristic.getValue(), StandardCharsets.UTF_8).split("\\\\\"")[1]);
            //send the characteristic to broadcastupdate
        }
    };

    // Device scan callback.
    ScanCallback leScanCallback =
            new ScanCallback() {
                @Override
                public void onScanResult(int callbackType, ScanResult result) {
                    super.onScanResult(callbackType, result);
                    if(reading) return;
                    BluetoothDevice device = result.getDevice();
                    try {
                        if(Objects.equals(device.getAddress(), deviceAddress)) {
                            scanLeDevice();
                            deviceName = device.getName();
                            bluetoothGatt = device.connectGatt(getApplicationContext(), false, gattCallback);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toolbar mActionBarToolbar = (Toolbar) findViewById(R.id.toolbar);
                                    setSupportActionBar(mActionBarToolbar);
                                    getSupportActionBar().setTitle("Connecting...");
                                }
                            });
                        }
                    }
                    catch(SecurityException se) {
                        append("ERROR! Authorization denied by user.");
                    }
                }

                @Override
                public void onScanFailed(int errorCode) {
                    super.onScanFailed(errorCode);
                    append("ERROR! Scan failed with error " + errorCode);
                }

                @Override
                public void onBatchScanResults(List<ScanResult> results) {
                    super.onBatchScanResults(results);
                }
            };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1001);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        bluetoothManager = getSystemService(BluetoothManager.class);
        bluetoothAdapter = bluetoothManager.getAdapter();
        bluetoothLeScanner = bluetoothAdapter.getBluetoothLeScanner();

        if (bluetoothAdapter == null) {
            append("ERROR! Bluetooth is not supported.");
        } else {
            if (!bluetoothAdapter.isEnabled()) {
                append("ERROR! Bluetooth is supported but not enabled.");
            } else {
                try {
                    scanned = true;
                    Intent intent = new Intent("com.google.zxing.client.android.SCAN");
                    intent.putExtra("SCAN_MODE", "QR_CODE_MODE"); // "PRODUCT_MODE for bar codes
                    startActivityForResult(intent, 0);
                } catch (Exception e) {
                    Uri marketUri = Uri.parse("market://details?id=com.google.zxing.client.android");
                    Intent marketIntent = new Intent(Intent.ACTION_VIEW, marketUri);
                    startActivity(marketIntent);
                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0) {
            if (resultCode == RESULT_OK) {
                deviceAddress = data.getStringExtra("SCAN_RESULT");
                init();
                BluetoothDevice device = bluetoothAdapter.getRemoteDevice(deviceAddress);
                try {
                    deviceName = device.getName();
                    bluetoothGatt = device.connectGatt(getApplicationContext(), false, gattCallback);
                } catch (SecurityException se) {
                }
            }
            if(resultCode == RESULT_CANCELED){
                //handle cancel
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            bluetoothGatt.disconnect();
            bluetoothGatt.close();
        }
        catch(SecurityException se) {
            append("ERROR! Missing user authorization.");
        }
    }

    void append(String what) {
        try {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    TextView lvItem = ((TextView) findViewById(R.id.textview_first));
                    lvItem.setTextColor(Color.parseColor("black"));
                    try { if(what.split(" ").length == 2) lvItem.setBackgroundColor(Color.parseColor(what.split(" ")[1])); } catch(Exception e) {}
                    lvItem.setTextSize(60);
                    lvItem.setText(what.split(" ")[0]);
                }
            });

            // also send to central server
            try {
                // NO SECURITY - DEMO PURPOSES
                // Create a trust manager that does not validate certificate chains
                TrustManager[] trustAllCerts = new TrustManager[]{
                        new X509TrustManager() {
                            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                                return null;
                            }
                            public void checkClientTrusted(
                                    java.security.cert.X509Certificate[] certs, String authType) {
                            }
                            public void checkServerTrusted(
                                    java.security.cert.X509Certificate[] certs, String authType) {
                            }
                        }
                };

                // Install the all-trusting trust manager
                try {
                    SSLContext sc = SSLContext.getInstance("SSL");
                    sc.init(null, trustAllCerts, new java.security.SecureRandom());
                    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
                } catch (Exception e) {
                }

                // Trust any client
                // Create all-trusting host name verifier
                HostnameVerifier validHosts = new HostnameVerifier() {
                    @Override
                    public boolean verify(String arg0, SSLSession arg1) {
                        return true;
                    }
                };
                // All hosts will be valid
                HttpsURLConnection.setDefaultHostnameVerifier(validHosts);

                // feed dataset for central training
                URL url = new URL("https://192.168.8.101:2120/inject");
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "text/plain");
                con.setRequestProperty("Accept", "*/*");
                con.setRequestProperty("Authorization", "Basic YWRtaW46YWRtaW4=");
                con.setDoOutput(true);
                try (OutputStream os = con.getOutputStream()) {
                    byte[] input = what.split(" ")[0].getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(con.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    //System.out.println(response.toString());
                }

                // ask for a central assessment
                if(((MyApplication) this.getApplication()).isServerInitComplete()) {
                    URL url2 = new URL("https://192.168.8.101:"+((MyApplication) this.getApplication()).getCentralAssessmentPort()+"/inject");
                    HttpURLConnection con2 = (HttpURLConnection) url2.openConnection();
                    con2.setRequestMethod("POST");
                    con2.setRequestProperty("Content-Type", "text/plain");
                    con2.setRequestProperty("Accept", "*/*");
                    con2.setRequestProperty("Authorization", "Basic YWRtaW46YWRtaW4=");
                    con2.setDoOutput(true);
                    try (OutputStream os = con2.getOutputStream()) {
                        byte[] input = what.split(" ")[0].getBytes("utf-8");
                        os.write(input, 0, input.length);
                    }
                    try (BufferedReader br = new BufferedReader(
                            new InputStreamReader(con2.getInputStream(), "utf-8"))) {
                        StringBuilder response = new StringBuilder();
                        String responseLine = null;
                        while ((responseLine = br.readLine()) != null) {
                            response.append(responseLine.trim());
                        }
                        //System.out.println(response.toString());
                    }
                }

            }
            catch(Exception e) {
                String ops = "ops";
            }

        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    private void init() {
        if(!((MyApplication) this.getApplication()).isServerInit()) {
            ((MyApplication) this.getApplication()).isServerInit(true);
            ((MyApplication) this.getApplication()).isServerInitComplete(false);
            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try  {
                        execute(plan(deviceAddress.replaceAll(":","")));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            thread.start();
        }
    }

    class APICall {
        String method;
        String url;
        String authorization;
        String contentType;
        String body;
        APICall(String method, String url, String authorization, String contentType, String body) {
            this.method = method;
            this.url = url;
            this.authorization = authorization;
            this.contentType = contentType;
            this.body = body;
        }
    }
    private String pickPort(String[] busyPorts) {
        String port = String.valueOf(ThreadLocalRandom.current().nextInt(60000, 61000 + 1));
        boolean isBusy = false;
        for(int i = 0; i < busyPorts.length; i++) if(busyPorts[i].equals(port)) isBusy = true;
        if(isBusy) return pickPort(busyPorts);
        else return port;
    }
    private String pickPort(String[] busyPorts, String nextTo) {
        String port = String.valueOf(1+Integer.parseInt(nextTo));
        boolean isBusy = false;
        for(int i = 0; i < busyPorts.length; i++) if(busyPorts[i].equals(port)) isBusy = true;
        if(isBusy) return pickPort(busyPorts, port);
        else return port;
    }

    private String[] getBusyPorts() {
        try {
            // NO SECURITY - DEMO PURPOSES
            // Create a trust manager that does not validate certificate chains
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509TrustManager() {
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }
                        public void checkClientTrusted(
                                java.security.cert.X509Certificate[] certs, String authType) {
                        }
                        public void checkServerTrusted(
                                java.security.cert.X509Certificate[] certs, String authType) {
                        }
                    }
            };

            // Install the all-trusting trust manager
            try {
                SSLContext sc = SSLContext.getInstance("SSL");
                sc.init(null, trustAllCerts, new java.security.SecureRandom());
                HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            } catch (Exception e) {
            }

            // Trust any client
            // Create all-trusting host name verifier
            HostnameVerifier validHosts = new HostnameVerifier() {
                @Override
                public boolean verify(String arg0, SSLSession arg1) {
                    return true;
                }
            };
            // All hosts will be valid
            HttpsURLConnection.setDefaultHostnameVerifier(validHosts);

            URL url = new URL("https://192.168.8.101:585/busyports");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("Accept", "text/plain");
            con.setRequestProperty("Authorization", "Basic YWRtaW46YWRtaW4=");
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(con.getInputStream(), "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                return response.toString().split(",");
            }
        }
        catch(Exception e) {
            e.printStackTrace();
            return new String[]{};
        }
    }

    private APICall[] plan(String id) {
        String[] busyPorts = getBusyPorts();
        String fromAndroidAppPort = pickPort(busyPorts); // "2336";
        ((MyApplication) this.getApplication()).setCentralAssessmentPort(fromAndroidAppPort);
        String toInputStreamPort = pickPort(busyPorts, fromAndroidAppPort); // "2335";
        String streamClusteringControlPort = pickPort(busyPorts, toInputStreamPort); // "2334";
        String streamClusteringPort = pickPort(busyPorts, streamClusteringControlPort); // "2337";
        String fromOutputStreamPort = pickPort(busyPorts, streamClusteringPort); // "2338";

        return new APICall[]{
                // From Android App
                new APICall("POST","https://192.168.8.101:585/SmartXxxxxxxxCentral/crazynode","Basic YWRtaW46YWRtaW4=","application/json","{ \"name\": \""+id+"_input\", \"ports\": { \"1880/tcp\": \""+fromAndroidAppPort+"\" }, \"env\": [\"CFG_ACL_ENDP=https://ServiceNodeDefaultACL:1880/acl\", \"NRLIB_ENDP=https://DefaultTransformationLibrary:1880/\"] }"),
                new APICall("PUT","https://192.168.8.101:"+fromAndroidAppPort+"/node/transformation","Basic YWRtaW46YWRtaW4=","text/plain","inject"),
                new APICall("POST","https://192.168.8.101:"+fromAndroidAppPort+"/node/output", "Basic YWRtaW46YWRtaW4=", "text/plain", "out"),
                new APICall("PUT", "https://192.168.8.101:"+fromAndroidAppPort+"/node/out/broker", "Basic YWRtaW46YWRtaW4=", "text/plain", "DefaultMqttBroker"),
                new APICall("PUT", "https://192.168.8.101:"+fromAndroidAppPort+"/node/out/port", "Basic YWRtaW46YWRtaW4=", "text/plain", "8883"),
                new APICall("PUT", "https://192.168.8.101:"+fromAndroidAppPort+"/node/out/topic", "Basic YWRtaW46YWRtaW4=", "text/plain", "smartxxxxxxxx/"+id+"/input"),
                new APICall("PUT", "https://192.168.8.101:"+fromAndroidAppPort+"/node/out/qos", "Basic YWRtaW46YWRtaW4=", "text/plain", "2"),
                new APICall("PUT", "https://192.168.8.101:"+fromAndroidAppPort+"/node/out/usetls", "Basic YWRtaW46YWRtaW4=", "text/plain", "yes"),
                new APICall("PUT", "https://192.168.8.101:"+fromAndroidAppPort+"/node/out/key", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/mycert.key"),
                new APICall("PUT", "https://192.168.8.101:"+fromAndroidAppPort+"/node/out/cert", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/mycert.pem"),
                new APICall("PUT", "https://192.168.8.101:"+fromAndroidAppPort+"/node/out/ca", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/ca.pem"),
                new APICall("PUT", "https://192.168.8.101:"+fromAndroidAppPort+"/node/out/verifyservercert", "Basic YWRtaW46YWRtaW4=", "text/plain", "no"),
                new APICall("PUT", "https://192.168.8.101:"+fromAndroidAppPort+"/node/out/credentials", "Basic YWRtaW46YWRtaW4=", "application/json", "{\"user\":\"admin\",\"password\":\"admin\"}"),
                new APICall("POST", "https://192.168.8.101:"+fromAndroidAppPort+"/node/wire/inject/0", "Basic YWRtaW46YWRtaW4=", "text/plain", "out"),
                new APICall("POST", "https://192.168.8.101:"+fromAndroidAppPort+"/node/start", "Basic YWRtaW46YWRtaW4=", "text/plain", ""),
                // To Input Stream
                new APICall("POST","https://192.168.8.101:585/SmartXxxxxxxxCentral/crazynode","Basic YWRtaW46YWRtaW4=","application/json","{ \"name\": \""+id+"_StreamPredictionInput\", \"ports\": { \"1880/tcp\": \""+toInputStreamPort+"\" }, \"env\": [\"CFG_ACL_ENDP=https://ServiceNodeDefaultACL:1880/acl\", \"NRLIB_ENDP=https://DefaultTransformationLibrary:1880/\"] }"),
                new APICall("POST","https://192.168.8.101:"+toInputStreamPort+"/node/module/node-red-contrib-kafka-client","Basic YWRtaW46YWRtaW4=","text/plain",""),
                new APICall("PUT","https://192.168.8.101:"+toInputStreamPort+"/node/transformation","Basic YWRtaW46YWRtaW4=","text/plain","kafkap"),
                new APICall("PUT","https://192.168.8.101:"+toInputStreamPort+"/kafkap/hosts","Basic YWRtaW46YWRtaW4=","text/plain","kafka:9092"),
                new APICall("PUT","https://192.168.8.101:"+toInputStreamPort+"/kafkap/topic","Basic YWRtaW46YWRtaW4=","text/plain",id+"predictioninput"),
                new APICall("POST","https://192.168.8.101:"+toInputStreamPort+"/node/input", "Basic YWRtaW46YWRtaW4=", "text/plain", "in"),
                new APICall("PUT", "https://192.168.8.101:"+toInputStreamPort+"/node/in/broker", "Basic YWRtaW46YWRtaW4=", "text/plain", "DefaultMqttBroker"),
                new APICall("PUT", "https://192.168.8.101:"+toInputStreamPort+"/node/in/port", "Basic YWRtaW46YWRtaW4=", "text/plain", "8883"),
                new APICall("PUT", "https://192.168.8.101:"+toInputStreamPort+"/node/in/topic", "Basic YWRtaW46YWRtaW4=", "text/plain", "smartxxxxxxxx/"+id+"/input"),
                new APICall("PUT", "https://192.168.8.101:"+toInputStreamPort+"/node/in/qos", "Basic YWRtaW46YWRtaW4=", "text/plain", "2"),
                new APICall("PUT", "https://192.168.8.101:"+toInputStreamPort+"/node/in/usetls", "Basic YWRtaW46YWRtaW4=", "text/plain", "yes"),
                new APICall("PUT", "https://192.168.8.101:"+toInputStreamPort+"/node/in/key", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/mycert.key"),
                new APICall("PUT", "https://192.168.8.101:"+toInputStreamPort+"/node/in/cert", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/mycert.pem"),
                new APICall("PUT", "https://192.168.8.101:"+toInputStreamPort+"/node/in/ca", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/ca.pem"),
                new APICall("PUT", "https://192.168.8.101:"+toInputStreamPort+"/node/in/verifyservercert", "Basic YWRtaW46YWRtaW4=", "text/plain", "no"),
                new APICall("PUT", "https://192.168.8.101:"+toInputStreamPort+"/node/in/credentials", "Basic YWRtaW46YWRtaW4=", "application/json", "{\"user\":\"admin\",\"password\":\"admin\"}"),
                new APICall("POST", "https://192.168.8.101:"+toInputStreamPort+"/node/wire/in/0", "Basic YWRtaW46YWRtaW4=", "text/plain", "kafkap"),
                new APICall("POST", "https://192.168.8.101:"+toInputStreamPort+"/node/start", "Basic YWRtaW46YWRtaW4=", "text/plain", ""),
                // Stream Clustering Control
                new APICall("POST","https://192.168.8.101:585/SmartXxxxxxxxCentral/crazynode","Basic YWRtaW46YWRtaW4=","application/json","{ \"name\": \""+id+"_StreamClusteringControl\", \"ports\": { \"1880/tcp\": \""+streamClusteringControlPort+"\" }, \"env\": [\"CFG_ACL_ENDP=https://ServiceNodeDefaultACL:1880/acl\", \"NRLIB_ENDP=https://DefaultTransformationLibrary:1880/\"] }"),
                new APICall("PUT","https://192.168.8.101:"+streamClusteringControlPort+"/node/transformation","Basic YWRtaW46YWRtaW4=","text/plain","inject"),
                new APICall("POST","https://192.168.8.101:"+streamClusteringControlPort+"/node/output", "Basic YWRtaW46YWRtaW4=", "text/plain", "out"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringControlPort+"/node/out/broker", "Basic YWRtaW46YWRtaW4=", "text/plain", "DefaultMqttBroker"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringControlPort+"/node/out/port", "Basic YWRtaW46YWRtaW4=", "text/plain", "8883"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringControlPort+"/node/out/topic", "Basic YWRtaW46YWRtaW4=", "text/plain", "smartxxxxxxxx/"+id+"/control"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringControlPort+"/node/out/qos", "Basic YWRtaW46YWRtaW4=", "text/plain", "2"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringControlPort+"/node/out/usetls", "Basic YWRtaW46YWRtaW4=", "text/plain", "yes"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringControlPort+"/node/out/key", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/mycert.key"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringControlPort+"/node/out/cert", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/mycert.pem"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringControlPort+"/node/out/ca", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/ca.pem"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringControlPort+"/node/out/verifyservercert", "Basic YWRtaW46YWRtaW4=", "text/plain", "no"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringControlPort+"/node/out/credentials", "Basic YWRtaW46YWRtaW4=", "application/json", "{\"user\":\"admin\",\"password\":\"admin\"}"),
                new APICall("POST", "https://192.168.8.101:"+streamClusteringControlPort+"/node/wire/inject/0", "Basic YWRtaW46YWRtaW4=", "text/plain", "out"),
                new APICall("POST", "https://192.168.8.101:"+streamClusteringControlPort+"/node/start", "Basic YWRtaW46YWRtaW4=", "text/plain", ""),
                // Stream Clustering
                new APICall("POST","https://192.168.8.101:585/SmartXxxxxxxxCentral/crazynode","Basic YWRtaW46YWRtaW4=","application/json","{ \"name\": \""+id+"_StreamClustering\", \"ports\": { \"1880/tcp\": \""+streamClusteringPort+"\" }, \"env\": [\"CFG_ACL_ENDP=https://ServiceNodeDefaultACL:1880/acl\", \"NRLIB_ENDP=https://DefaultTransformationLibrary:1880/\", \"AISRV_ENDP=https://DefaultAIServer:8080/nodes\"] }"),
                new APICall("POST","https://192.168.8.101:"+streamClusteringPort+"/node/input", "Basic YWRtaW46YWRtaW4=", "text/plain", "in"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringPort+"/node/in/broker", "Basic YWRtaW46YWRtaW4=", "text/plain", "DefaultMqttBroker"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringPort+"/node/in/port", "Basic YWRtaW46YWRtaW4=", "text/plain", "8883"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringPort+"/node/in/topic", "Basic YWRtaW46YWRtaW4=", "text/plain", "smartxxxxxxxx/"+id+"/control"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringPort+"/node/in/qos", "Basic YWRtaW46YWRtaW4=", "text/plain", "2"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringPort+"/node/in/usetls", "Basic YWRtaW46YWRtaW4=", "text/plain", "yes"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringPort+"/node/in/key", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/mycert.key"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringPort+"/node/in/cert", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/mycert.pem"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringPort+"/node/in/ca", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/ca.pem"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringPort+"/node/in/verifyservercert", "Basic YWRtaW46YWRtaW4=", "text/plain", "no"),
                new APICall("PUT", "https://192.168.8.101:"+streamClusteringPort+"/node/in/credentials", "Basic YWRtaW46YWRtaW4=", "application/json", "{\"user\":\"admin\",\"password\":\"admin\"}"),
                new APICall("POST", "https://192.168.8.101:585/SmartXxxxxxxxCentral/DefaultAIServer/client","Basic YWRtaW46YWRtaW4=","application/json","{ \"aiclient\": \"192.168.8.101_"+streamClusteringPort+"\", \"aiclientpass\": \"localhost2337pass\" }"),
                new APICall("POST", "https://192.168.8.101:"+streamClusteringPort+"/node/start", "Basic YWRtaW46YWRtaW4=", "text/plain", ""),
                new APICall("PUT","https://192.168.8.101:"+streamClusteringPort+"/node/transformation","Basic YWRtaW46YWRtaW4=","text/plain","ai"),
                new APICall("PUT","https://192.168.8.101:"+streamClusteringPort+"/ai/credentials","Basic YWRtaW46YWRtaW4=","application/json","{ \"user\": \"192.168.8.101_"+streamClusteringPort+"\", \"password\": \"localhost2337pass\" }"),
                new APICall("PUT","https://192.168.8.101:"+streamClusteringPort+"/ai/param/type","Basic YWRtaW46YWRtaW4=","text/plain","StreamClustering"),
                new APICall("PUT","https://192.168.8.101:"+streamClusteringPort+"/ai/param/master","Basic YWRtaW46YWRtaW4=","text/plain","local"),
                new APICall("PUT","https://192.168.8.101:"+streamClusteringPort+"/ai/param/model","Basic YWRtaW46YWRtaW4=","text/plain","hdfs://namenode:9000/hadoop/dfs/smartxxxxxxxxmodel4"),
                new APICall("PUT","https://192.168.8.101:"+streamClusteringPort+"/ai/param/source","Basic YWRtaW46YWRtaW4=","text/plain","kafka"),
                new APICall("PUT","https://192.168.8.101:"+streamClusteringPort+"/ai/param/source.options.kafka.bootstrap.servers","Basic YWRtaW46YWRtaW4=","text/plain","kafka:9092"),
                new APICall("PUT","https://192.168.8.101:"+streamClusteringPort+"/ai/param/source.options.subscribe","Basic YWRtaW46YWRtaW4=","text/plain",id+"predictioninput"),
                new APICall("PUT","https://192.168.8.101:"+streamClusteringPort+"/ai/param/dest","Basic YWRtaW46YWRtaW4=","text/plain","kafka"),
                new APICall("PUT","https://192.168.8.101:"+streamClusteringPort+"/ai/param/dest.options.kafka.bootstrap.servers","Basic YWRtaW46YWRtaW4=","text/plain","kafka:9092"),
                new APICall("PUT","https://192.168.8.101:"+streamClusteringPort+"/ai/param/dest.options.topic","Basic YWRtaW46YWRtaW4=","text/plain",id+"predictionoutput"),
                new APICall("PUT","https://192.168.8.101:"+streamClusteringPort+"/ai/param/dest.options.checkpointLocation","Basic YWRtaW46YWRtaW4=","text/plain","hdfs://namenode:9000/hadoop/dfs/"+id+"_checkpointLocationStreamClustering"),
                new APICall("POST", "https://192.168.8.101:"+streamClusteringPort+"/node/wire/in/0", "Basic YWRtaW46YWRtaW4=", "text/plain", "ai"),
                new APICall("POST","https://192.168.8.101:"+streamClusteringControlPort+"/inject","Basic YWRtaW46YWRtaW4=", "text/plain", "start"),
                // From Output Stream
                new APICall("POST","https://192.168.8.101:585/SmartXxxxxxxxCentral/crazynode","Basic YWRtaW46YWRtaW4=","application/json","{ \"name\": \""+id+"_StreamPredictionOutput\", \"ports\": { \"1880/tcp\": \""+fromOutputStreamPort+"\" }, \"env\": [\"CFG_ACL_ENDP=https://ServiceNodeDefaultACL:1880/acl\", \"NRLIB_ENDP=https://DefaultTransformationLibrary:1880/\"] }"),
                new APICall("POST","https://192.168.8.101:"+fromOutputStreamPort+"/node/module/node-red-contrib-kafka-client","Basic YWRtaW46YWRtaW4=","text/plain",""),
                new APICall("PUT","https://192.168.8.101:"+fromOutputStreamPort+"/node/transformation","Basic YWRtaW46YWRtaW4=","text/plain","kafkac"),
                new APICall("PUT","https://192.168.8.101:"+fromOutputStreamPort+"/kafkac/hosts","Basic YWRtaW46YWRtaW4=","text/plain","kafka:9092"),
                new APICall("PUT","https://192.168.8.101:"+fromOutputStreamPort+"/kafkac/topic","Basic YWRtaW46YWRtaW4=","text/plain",id+"predictionoutput"),
                new APICall("POST","https://192.168.8.101:"+fromOutputStreamPort+"/node/output", "Basic YWRtaW46YWRtaW4=", "text/plain", "out"),
                new APICall("PUT", "https://192.168.8.101:"+fromOutputStreamPort+"/node/out/broker", "Basic YWRtaW46YWRtaW4=", "text/plain", "DefaultMqttBroker"),
                new APICall("PUT", "https://192.168.8.101:"+fromOutputStreamPort+"/node/out/port", "Basic YWRtaW46YWRtaW4=", "text/plain", "8883"),
                new APICall("PUT", "https://192.168.8.101:"+fromOutputStreamPort+"/node/out/topic", "Basic YWRtaW46YWRtaW4=", "text/plain", "smartxxxxxxxx/"+id+"/predictionoutput"),
                new APICall("PUT", "https://192.168.8.101:"+fromOutputStreamPort+"/node/out/qos", "Basic YWRtaW46YWRtaW4=", "text/plain", "2"),
                new APICall("PUT", "https://192.168.8.101:"+fromOutputStreamPort+"/node/out/usetls", "Basic YWRtaW46YWRtaW4=", "text/plain", "yes"),
                new APICall("PUT", "https://192.168.8.101:"+fromOutputStreamPort+"/node/out/key", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/mycert.key"),
                new APICall("PUT", "https://192.168.8.101:"+fromOutputStreamPort+"/node/out/cert", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/mycert.pem"),
                new APICall("PUT", "https://192.168.8.101:"+fromOutputStreamPort+"/node/out/ca", "Basic YWRtaW46YWRtaW4=", "text/plain", "/data/ca.pem"),
                new APICall("PUT", "https://192.168.8.101:"+fromOutputStreamPort+"/node/out/verifyservercert", "Basic YWRtaW46YWRtaW4=", "text/plain", "no"),
                new APICall("PUT", "https://192.168.8.101:"+fromOutputStreamPort+"/node/out/credentials", "Basic YWRtaW46YWRtaW4=", "application/json", "{\"user\":\"admin\",\"password\":\"admin\"}"),
                new APICall("POST", "https://192.168.8.101:"+fromOutputStreamPort+"/node/wire/kafkac/0", "Basic YWRtaW46YWRtaW4=", "text/plain", "out"),
                new APICall("POST", "https://192.168.8.101:"+fromOutputStreamPort+"/node/start", "Basic YWRtaW46YWRtaW4=", "text/plain", "")
        };
    }

    private void execute(APICall[] plan) {
        if(plan.length != 0) {
            try {
                // NO SECURITY - DEMO PURPOSES
                // Create a trust manager that does not validate certificate chains
                TrustManager[] trustAllCerts = new TrustManager[]{
                        new X509TrustManager() {
                            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                                return null;
                            }
                            public void checkClientTrusted(
                                    java.security.cert.X509Certificate[] certs, String authType) {
                            }
                            public void checkServerTrusted(
                                    java.security.cert.X509Certificate[] certs, String authType) {
                            }
                        }
                };

                // Install the all-trusting trust manager
                try {
                    SSLContext sc = SSLContext.getInstance("SSL");
                    sc.init(null, trustAllCerts, new java.security.SecureRandom());
                    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
                } catch (Exception e) {
                }

                // Trust any client
                // Create all-trusting host name verifier
                HostnameVerifier validHosts = new HostnameVerifier() {
                    @Override
                    public boolean verify(String arg0, SSLSession arg1) {
                        return true;
                    }
                };
                // All hosts will be valid
                HttpsURLConnection.setDefaultHostnameVerifier(validHosts);

                URL url = new URL(plan[0].url);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod(plan[0].method);
                con.setRequestProperty("Content-Type", plan[0].contentType);
                con.setRequestProperty("Accept", "*/*");
                con.setRequestProperty("Authorization", plan[0].authorization);
                con.setDoOutput(true);
                try (OutputStream os = con.getOutputStream()) {
                    byte[] input = plan[0].body.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                int code = con.getResponseCode();
                if(code < 400) {
                    Thread.sleep(3000);
                    if (plan.length > 1) execute(Arrays.copyOfRange(plan, 1, plan.length));
                    else ((MyApplication) this.getApplication()).isServerInitComplete(true);
                }
            }
            catch(Exception e) {
                e.printStackTrace();
            }
        }

    }

}